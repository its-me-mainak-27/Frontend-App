import React, { createContext, useContext, useState } from 'react';

const ChatContext = createContext();

export const ChatProvider = ({ children }) => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  const sendMessage = (text) => {
    const userMessage = { text, sender: 'user' };
    const botMessage = { text: `AI says: ${text}`, sender: 'bot' };
    setMessages([...messages, userMessage, botMessage]);
  };

  return (
    <ChatContext.Provider value={{ messages, sendMessage, loading }}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => useContext(ChatContext);
