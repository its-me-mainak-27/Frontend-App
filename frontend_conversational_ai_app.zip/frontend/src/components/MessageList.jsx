import React from 'react';
import Message from './Message';

const MessageList = ({ messages }) => (
  <div className="space-y-2">
    {messages.map((msg, index) => (
      <Message key={index} {...msg} />
    ))}
  </div>
);

export default MessageList;
