import React from 'react';

const Message = ({ text, sender }) => (
  <div className={`p-2 rounded-xl ${sender === 'user' ? 'bg-blue-100 self-end' : 'bg-gray-100 self-start'}`}> 
    <span className="text-sm">{text}</span>
  </div>
);

export default Message;
