import React from 'react';
import MessageList from './MessageList';
import UserInput from './UserInput';

const ChatWindow = ({ messages, onSend }) => (
  <div className="p-4 bg-white rounded-2xl shadow-md h-full flex flex-col">
    <div className="flex-grow overflow-y-auto">
      <MessageList messages={messages} />
    </div>
    <UserInput onSend={onSend} />
  </div>
);

export default ChatWindow;
