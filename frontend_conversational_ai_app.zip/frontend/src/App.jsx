import React from 'react';
import { ChatProvider, useChat } from './context/ChatContext';
import ChatWindow from './components/ChatWindow';

const ChatApp = () => {
  const { messages, sendMessage } = useChat();

  return (
    <div className="h-screen bg-gray-100 p-6">
      <div className="max-w-xl mx-auto h-full">
        <ChatWindow messages={messages} onSend={sendMessage} />
      </div>
    </div>
  );
};

const App = () => (
  <ChatProvider>
    <ChatApp />
  </ChatProvider>
);

export default App;
